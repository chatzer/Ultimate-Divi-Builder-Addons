/*
 Revealator jQuery Plugin
 Revealator is a jQuery-based plugin for adding effects to elements that enter the window. It's simple, and easy to use.
 version 1.4, Jan 11th, 2016
 by Ingi P. Jacobsen

 The MIT License (MIT)

 Copyright (c) 2016 Faroe Media

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
 */


var Revealator = typeof Revealator !== 'undefined' ? Revealator : {};

jQuery(function () {
	Revealator = jQuery.extend({}, {
		timer:           null,
		busy:            false,
		scroll_padding:  0,
		effects_padding: 0,
		refresh:         function () {}
	}, typeof Revealator !== 'undefined' ? Revealator : {});

	Revealator.refresh = function () {
		var jQuerywindow = jQuery(window);
		var jQuerydocument = jQuery(document);
		var jQuerybody = jQuery(document.body);
		var i = 0;
		var window_top = Revealator.effects_padding;
		var window_bottom = jQuerywindow.height() - Revealator.effects_padding;
		var document_top = Revealator.scroll_padding;
		var document_bottom = jQuerydocument.height() - Revealator.scroll_padding;
		
		if (jQuerywindow.scrollTop() === 0) {
			if (!jQuerybody.hasClass('at-top')) {
				jQuerybody.addClass('at-top').removeClass('at-bottom').removeClass('near-top').removeClass('near-bottom');
			}
		} else if (jQuerywindow.scrollTop() + jQuerywindow.height() === jQuerydocument.height()) {
			if (!jQuerybody.hasClass('at-bottom')) {
				jQuerybody.addClass('at-bottom').removeClass('at-top').removeClass('near-top').removeClass('near-bottom');
			}
		} else if (jQuerywindow.scrollTop() <= document_top) {
			if (!jQuerybody.hasClass('near-top')) {
				jQuerybody.addClass('near-top').removeClass('near-bottom').removeClass('at-top').removeClass('at-bottom');
			}
		} else if (jQuerywindow.scrollTop() + jQuerywindow.height() >= document_bottom) {
			if (!jQuerybody.hasClass('near-bottom')) {
				jQuerybody.addClass('near-bottom').removeClass('near-top').removeClass('at-top').removeClass('at-bottom');
			}
		} else {
			if (jQuerybody.hasClass('at-top') || jQuerybody.hasClass('at-bottom') || jQuerybody.hasClass('near-top') || jQuerybody.hasClass('near-bottom')) {
				jQuerybody.removeClass('at-top').removeClass('at-bottom').removeClass('near-top').removeClass('near-bottom');
			}
		}
		
		jQuery('*[class*="revealator"]').each(function () {
			i++;
			var element = this;
			var jQueryelement = jQuery(element);
			var element_bounding = element.getBoundingClientRect();

			var position_class = undefined;
			if (element_bounding.top > window_bottom && element_bounding.bottom > window_bottom) {
				position_class = 'revealator-below';
			} else if (element_bounding.top < window_bottom && element_bounding.bottom > window_bottom) {
				position_class = 'revealator-partially-below'
			} else if (element_bounding.top < window_top && element_bounding.bottom > window_top) {
				position_class = 'revealator-partially-above'
			} else if (element_bounding.top < window_top && element_bounding.bottom < window_top) {
				position_class = 'revealator-above';
			} else {
				position_class = 'revealator-within';
			}

			if (jQueryelement.hasClass('revealator-load') && !jQueryelement.hasClass('revealator-within')) {
				jQueryelement.removeClass('revealator-below revealator-partially-below revealator-within revealator-partially-above revealator-above');
				jQueryelement.addClass('revealator-within');
			}

			if (!jQueryelement.hasClass(position_class) && !jQueryelement.hasClass('revealator-load')) {
				if (jQueryelement.hasClass('revealator-once')) {
					if (!jQueryelement.hasClass('revealator-within')) {
						jQueryelement.removeClass('revealator-below revealator-partially-below revealator-within revealator-partially-above revealator-above');
						jQueryelement.addClass(position_class);
					}
					if (jQueryelement.hasClass('revealator-partially-above') || jQueryelement.hasClass('revealator-above')) {
						jQueryelement.addClass('revealator-within');
					}
				} else {
					jQueryelement.removeClass('revealator-below revealator-partially-below revealator-within revealator-partially-above revealator-above');
					jQueryelement.addClass(position_class);
				}
			}
		});
	};

	jQuery(window).bind('scroll resize load ready', function () {
		if (!Revealator.busy) {
			Revealator.busy = true;
			setTimeout(function () {
				Revealator.busy = false;
				Revealator.refresh();
			}, 150);
		}
	});
});