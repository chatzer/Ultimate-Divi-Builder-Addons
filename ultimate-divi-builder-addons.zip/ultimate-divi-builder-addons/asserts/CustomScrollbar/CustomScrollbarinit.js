jQuery(window).on("load",function(){
if( jQuery('body').find('.CustomScrollbarEffect1').length >0 ){	
			jQuery(".CustomScrollbarEffect1").mCustomScrollbar({
					theme:"minimal"
			});
}

if( jQuery('body').find('.CustomScrollbarEffect2').length >0 ){	
				jQuery(".CustomScrollbarEffect2").mCustomScrollbar({
					autoHideScrollbar:true,
					theme:"rounded"
				});
}


if( jQuery('body').find('.CustomScrollbarEffect3').length >0 ){	
				var content=jQuery(".CustomScrollbarEffect3"),autoScrollTimer=30000,autoScrollTimerAdjust,autoScroll;
				
				content.mCustomScrollbar({
					scrollButtons:{enable:true},
					callbacks:{
						whileScrolling:function(){
							autoScrollTimerAdjust=autoScrollTimer*this.mcs.topPct/100;
						},
						onScroll:function(){ 
							if($(this).data("mCS").trigger==="internal"){AutoScrollOff();}
						}
					}
				});
				
				content.addClass("auto-scrolling-on auto-scrolling-to-bottom");
				AutoScrollOn("bottom");
				
				jQuery(".auto-scrolling-toggle").click(function(e){
					e.preventDefault();
					if(content.hasClass("auto-scrolling-on")){
						AutoScrollOff();
					}else{
						if(content.hasClass("auto-scrolling-to-top")){
							AutoScrollOn("top",autoScrollTimerAdjust);
						}else{
							AutoScrollOn("bottom",autoScrollTimer-autoScrollTimerAdjust);
						}
					}
				});
				
				function AutoScrollOn(to,timer){
					if(!timer){timer=autoScrollTimer;}
					content.addClass("auto-scrolling-on").mCustomScrollbar("scrollTo",to,{scrollInertia:timer,scrollEasing:"easeInOutSmooth"});
					autoScroll=setTimeout(function(){
						if(content.hasClass("auto-scrolling-to-top")){
							AutoScrollOn("bottom",autoScrollTimer-autoScrollTimerAdjust);
							content.removeClass("auto-scrolling-to-top").addClass("auto-scrolling-to-bottom");
						}else{
							AutoScrollOn("top",autoScrollTimerAdjust);
							content.removeClass("auto-scrolling-to-bottom").addClass("auto-scrolling-to-top");
						}
					},timer);
				}
				
				function AutoScrollOff(){
					clearTimeout(autoScroll);
					content.removeClass("auto-scrolling-on").mCustomScrollbar("stop");
				}
}


if( jQuery('body').find('.CustomScrollbarEffect4').length >0 ){	
				jQuery(".CustomScrollbarEffect4").mCustomScrollbar({
					theme:"rounded-dots",
					scrollInertia:400
				});
}

if( jQuery('body').find('.CustomScrollbarEffect5').length >0 ){	
				jQuery(".CustomScrollbarEffect5").mCustomScrollbar({
					scrollButtons:{enable:true,scrollType:"stepped"},
					keyboard:{scrollType:"stepped"},
					mouseWheel:{scrollAmount:188},
					theme:"rounded-dark",
					autoExpandScrollbar:true,
					snapAmount:188,
					snapOffset:65
				});
}

if( jQuery('body').find('.CustomScrollbarEffect6').length >0 ){	
				jQuery(".CustomScrollbarEffect6").mCustomScrollbar({
					axis:"yx",
					scrollButtons:{enable:true},
					theme:"3d",
					scrollbarPosition:"outside"
				});
}

if( jQuery('body').find('.CustomScrollbarEffect7').length >0 ){	
				jQuery(".CustomScrollbarEffect7").mCustomScrollbar({
					scrollButtons:{enable:true},
					theme:"3d-thick"
				});
}
				
});