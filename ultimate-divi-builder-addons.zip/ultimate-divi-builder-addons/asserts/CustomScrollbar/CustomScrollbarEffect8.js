	jQuery(window).on("load",function($){
if( jQuery('body').find('#et-main-area').length >0 ){	
				jQuery("#et-main-area").mCustomScrollbar({
					theme:"minimal"
				});
}
	});