jQuery(document).ready(function($) {
if( jQuery('body').find('.et_pb_section_pagepiling').length >0 ){		
	/*
			* Plugin intialization
			*/
			jQuery('html, body').css('overflow','hidden');
	    	jQuery('#main-content').pagepiling({ 
				loopTop: true,
			    loopBottom: true
	    	});
}
});
(function(){
    // Override the addClass to prevent fixed header class from being added
    var addclass = jQuery.fn.addClass;
    jQuery.fn.addClass = function(){
        var result = addclass.apply(this, arguments);
            jQuery('#main-header').removeClass('et-fixed-header');
        return result;
    }
})();
jQuery(function($){
    $('#main-header').removeClass('et-fixed-header');
});