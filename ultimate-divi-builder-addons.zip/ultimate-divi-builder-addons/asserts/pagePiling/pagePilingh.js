jQuery(document).ready(function($) {
if( jQuery('body').find('.et_pb_section_pagepiling').length >0 ){		
	/*
			* Plugin intialization
			*/
			jQuery('html, body').css('overflow','hidden');
	    	jQuery('#et-main-area').pagepiling({ 
				loopTop: true,
			    loopBottom: true,
				direction: 'horizontal',
				verticalCentered: true,
				scrollingSpeed: 700,
				easing: 'swing', 
				normalScrollElements: null,
				normalScrollElementTouchThreshold: 5,
				touchSensitivity: 5,
				keyboardScrolling: true,
				sectionSelector: '.et_pb_section_pagepiling',
				animateAnchor: false,
	    	});
}
});
(function(){
    // Override the addClass to prevent fixed header class from being added
    var addclass = jQuery.fn.addClass;
    jQuery.fn.addClass = function(){
        var result = addclass.apply(this, arguments);
            jQuery('#main-header').removeClass('et-fixed-header');
        return result;
    }
})();
jQuery(function($){
    $('#main-header').removeClass('et-fixed-header');
});