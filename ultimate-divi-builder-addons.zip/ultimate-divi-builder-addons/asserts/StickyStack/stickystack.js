jQuery(window).load(function() {

if( jQuery('body').find('.et_pb_section_sticky').length >0 ){	
  jQuery('.et_pb_section_sticky').css('min-height', jQuery(window).height());

  jQuery('.entry-content').stickyStack({
        containerElement: '.entry-content',
        stackingElement: 'div',
        boxShadow: '0 -3px 20px rgba(0, 0, 0, 0.25)'
    });
}
});
