jQuery(document).ready(function ($) {

if( jQuery('body').find('#main-content ul').length >0 ){	
	stroll.bind( '#main-content ul' );
}

});			
	