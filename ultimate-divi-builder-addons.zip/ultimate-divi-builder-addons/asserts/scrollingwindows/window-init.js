jQuery(document).ready(function ($) {
if( jQuery('body').find('.window').length >0 ){	

var $windows = $('.window');

                $windows.windows({
                    snapping: true,
                    snapSpeed: 500,
                    snapInterval: 1100,
                    onScroll: function(s){},
                    onSnapComplete: function($el){},
                    onWindowEnter: function($el){}
                });
}
				
});			
				
				