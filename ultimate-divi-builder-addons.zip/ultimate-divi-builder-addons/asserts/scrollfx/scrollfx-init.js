 jQuery(document).ready(function($){
if( jQuery('body').find('.scrollfx').length >0 ){	
  jQuery('.scrollfx').scrollFx({
      precision: 2,
      scaleElements: '.et_pb_row',
      opacityElements: '.et_pb_row,.et_pb_module'
    });
}
  });