(function() {
    jQuery.fn.scrollFx = function(a) {
        var b, c, d, e, f, g;
        this.settings = jQuery.extend({
            scaleElements: "",
            opacityElements: "",
            precision: 10
        }, a);
        b = this;
        b.win = jQuery(window);
        b.doc = jQuery(document);
        b.st = jQuery(window).scrollTop();
        b.els = this;
        b.precision = b.settings.precision;
        b.scaleEls = b.settings.scaleElements;
        b.opacityEls = b.settings.opacityElements;
        jQuery(function() {
            b.positions = f();
            return b.active_el = e();
        });
        g = function() {
            b.st = b.win.scrollTop();
            return b.active_el = e();
        };
        f = function() {
            var a;
            a = [];
            b.els.each(function(b, c) {
                var d, e;
                e = jQuery(c).position().top;
                d = jQuery(c).outerHeight();
                return a.push({
                    item: jQuery(c),
                    top: e,
                    height: d,
                    bottom: e + d
                });
            });
            return a;
        };
        e = function() {
            var a, d;
            a = false;
            d = b.st;
            jQuery(b.positions).each(function(b, e) {
                if (d >= e.top && d <= e.bottom) {
                    c(e);
                    return a = e.item;
                }
            });
            return a;
        };
        c = function(a) {
            var c, e, f;
            e = d(a);
            c = 1 - (e * .01).toFixed(b.precision);
            f = 1 - (e * .002).toFixed(b.precision);
            jQuery(a.item).find(b.opacityEls).css("opacity", c);
            return jQuery(a.item).find(b.scaleEls).css({
                transform: "scale(" + f + ")",
                "-webkit-transform": "scale(" + f + ")"
            });
        };
        d = function(a) {
            var c, d;
            c = b.st - a.top;
            d = (100 / a.height * c).toFixed(b.precision);
            return d;
        };
        b.win.scroll(function() {
            return g();
        });
        return b.win.resize(function() {
            b.positions = f();
            return g();
        });
    };
}).call(this);