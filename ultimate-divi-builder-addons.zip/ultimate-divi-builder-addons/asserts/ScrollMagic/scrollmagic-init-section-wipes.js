jQuery(document).ready(function ($) {

// init Section Wipes (natural)
var controllerWipes = new ScrollMagic.Controller({
	globalSceneOptions: {
		triggerHook: 'onLeave'
	}
});

// get all slides
var slidesWipes = document.querySelectorAll("div.section-wipes-panel");

// create scene for every slide
for (var i=0; i<slidesWipes.length; i++) {
	new ScrollMagic.Scene({
			triggerElement: slidesWipes[i]
		})
		.setPin(slidesWipes[i], {pushFollowers: false})
		.addTo(controllerWipes);
}
});				
				
				
				