jQuery(document).ready(function ($) {
if( jQuery('body').find('.responsive-duration-trigger').length >0 ){							 
 // init controller ScrollMagic Responsive Duration
var controller = new ScrollMagic.Controller();

// build tween
var tween = TweenMax.to(".responsive-duration-animate", 0.5, {scale: 1.3, repeat: 5, yoyo: true});

// build scene and set duration to window height
var scene = new ScrollMagic.Scene({triggerElement: ".responsive-duration-trigger", duration: "100%"})
			.setTween(tween)
			.addTo(controller);
}

});				
