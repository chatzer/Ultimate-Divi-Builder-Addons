jQuery(document).ready(function ($) {
  
    var scrollt = jQuery(document).scrollTop();
    var header_main = jQuery('#main-header').outerHeight();

    jQuery(window).scroll(function() {
        var scrollt1 = jQuery(document).scrollTop();

        if (scrollt1 > header_main){jQuery('#main-header').addClass('gizle');jQuery('body').addClass('menuhide');} 
        else {$('#main-header').removeClass('gizle');jQuery('body').removeClass('menuhide');}

        if (scrollt1 > scrollt){jQuery('#main-header').removeClass('sabit');jQuery('#main-header').removeClass('open');jQuery('#main-header').addClass('close');jQuery('body').removeClass('menushow');} 
        else {jQuery('#main-header').addClass('sabit');jQuery('#main-header').addClass('open');jQuery('#main-header').removeClass('close');jQuery('body').addClass('menushow');}				

        scrollt = jQuery(document).scrollTop();	
     });
});

