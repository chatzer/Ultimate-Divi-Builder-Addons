jQuery(document).ready(function ($) {
  
   
 if( jQuery('body').find('.simpletextrotator').length >0 ){	 
   
	  $(".simpletextrotator .rotate").textrotator({
        animation: "fade",
        speed: 1000
      });
 }
 if( jQuery('body').find('.simpletextrotatore1').length >0 ){	 

      $(".simpletextrotatore1 .rotate").textrotator({
        animation: "flip",
        speed: 1250
      });
 }
 if( jQuery('body').find('.simpletextrotatore2').length >0 ){	 
      $(".simpletextrotatore2 .rotate").textrotator({
        animation: "flipCube",
        speed: 1500
      });
  }
 if( jQuery('body').find('.simpletextrotatore3').length >0 ){	 
      $(".simpletextrotatore3 .rotate").textrotator({
        animation: "flipUp",
        speed: 1750
      });
 }
 if( jQuery('body').find('.simpletextrotatore4').length >0 ){	 
      $(".simpletextrotatore4 .rotate").textrotator({
        animation: "spin",
        speed: 2000
      });
 }
 
  
});			
				
				