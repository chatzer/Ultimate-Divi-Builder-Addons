jQuery(document).ready(function ($) {
 if( jQuery('body').find('.scrollTriggerdiv').length >0 ){	
		$('.scrollTriggerdiv div').scrollTrigger();
 }
});	
