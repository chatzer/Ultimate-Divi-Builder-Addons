jQuery(document).ready(function () {
								 
	window.sr = ScrollReveal();
	if( jQuery('body').find('.scrollreveal').length >0 ){							 
		// JavaScript
		
		sr.reveal('.scrollreveal' ,{useDelay: 'always',reset:true, duration: 2000,delay: 50 ,scale: 0.5 });
 
	  
	}
	
	if( jQuery('body').find('.scrollreveal1').length >0 ){							 
		// JavaScript
		
		sr.reveal('.scrollreveal1' ,{useDelay: 'always',reset:true, duration: 2000,delay: 50 ,scale: 1.0 });
 
	  
	}
	
	
	if( jQuery('body').find('.scrollrevealEffect1').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect1 = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { z: 10 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect1', scrollrevealEffect1);
		sr.reveal('.scrollrevealEffect1', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect1a').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect1a = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { z: 50 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect1a', scrollrevealEffect1a);
		sr.reveal('.scrollrevealEffect1a', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect1b').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect1b = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { z: 90 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect1b', scrollrevealEffect1b);
		sr.reveal('.scrollrevealEffect1b', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect1c').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect1c = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { z: 150 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect1c', scrollrevealEffect1c);
		sr.reveal('.scrollrevealEffect1c', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect1d').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect1d = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { z: 225 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect1d', scrollrevealEffect1d);
		sr.reveal('.scrollrevealEffect1d', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect1e').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect1e = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { z: 360 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect1e', scrollrevealEffect1e);
		sr.reveal('.scrollrevealEffect1e', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect1f').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect1f = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { z: 500 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect1f', scrollrevealEffect1f);
		sr.reveal('.scrollrevealEffect1f', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect1g').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect1g = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { z: 2500 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect1g', scrollrevealEffect1g);
		sr.reveal('.scrollrevealEffect1g', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect2').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect1 = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { x: 10 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect2', scrollrevealEffect1);
		sr.reveal('.scrollrevealEffect2', { reset:true,delay: 500, scale: 0.9 });
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect3').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect3 = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { x: 45 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect3', scrollrevealEffect3);
		sr.reveal('.scrollrevealEffect3', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect4').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect4 = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { x: 75 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect4', scrollrevealEffect4);
		sr.reveal('.scrollrevealEffect4', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect5').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect5 = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { x: 90 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect5', scrollrevealEffect5);
		sr.reveal('.scrollrevealEffect5', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect6').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect6 = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { x: 125 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect6', scrollrevealEffect6);
		sr.reveal('.scrollrevealEffect6', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect7').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect7 = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { x: 200 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect7', scrollrevealEffect7);
		sr.reveal('.scrollrevealEffect7', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
	
	if( jQuery('body').find('.scrollrevealEffect8').length >0 ){							 
		// JavaScript
		
		var scrollrevealEffect8 = {
		  delay    : 200,
		  distance : '90px',
		  easing   : 'ease-in-out',
		  rotate   : { x: 360 },
		  scale    : 1.1
		};
		
		sr.reveal('.scrollrevealEffect8', scrollrevealEffect8);
		sr.reveal('.scrollrevealEffect8', { reset:true,delay: 500, scale: 0.9 });
		 
	  
	}
});