jQuery(function($) { 
$( "#main-header" ).after( '<div id="loading"></div>' );
function scroll_fn(){

    document_height = $(document).height();
    scroll_so_far = $(window).scrollTop();
    window_height = $(window).height();
    
	max_scroll = document_height-window_height;

	scroll_percentage = scroll_so_far/(max_scroll/102);
    
    $('#loading').width(scroll_percentage + '%');

}



jQuery(window).scroll(function() {
scroll_fn();
});

jQuery(window).resize(function() {
scroll_fn();
});

});