jQuery(function($) { 
$( "#main-header" ).after( '<div id="loading"></div>' );
var LoadingEffect = LoadingEffect4.LoadingEffect4colorft;
var primary_nav_bg = LoadingEffect4.primary_nav_bg;

function scroll_fn(){

    document_height = $(document).height();
    scroll_so_far = $(window).scrollTop();
    window_height = $(window).height();
    
	max_scroll = document_height-window_height;

	scroll_percentage = scroll_so_far/(max_scroll/100);
    
   
	 
$('#logo').css({background: "-webkit-gradient(linear, left top, right top, color-stop("+scroll_percentage+"%,"+LoadingEffect+"), color-stop("+scroll_percentage+"%,"+primary_nav_bg+"))" });
$('#logo').css({background: "-webkit-linear-gradient(left, "+LoadingEffect+" "+scroll_percentage+"%,"+primary_nav_bg+" "+scroll_percentage+"%)" });
$('#logo').css({background: "-moz-linear-gradient(left, "+LoadingEffect+" "+scroll_percentage+"%, "+primary_nav_bg+" "+scroll_percentage+"%)" });
$('#logo').css({background: "-o-linear-gradient(left, "+LoadingEffect+" "+scroll_percentage+"%,"+primary_nav_bg+" "+scroll_percentage+"%)" });
$('#logo').css({background: "-ms-linear-gradient(left, "+LoadingEffect+" "+scroll_percentage+"%,"+primary_nav_bg+" "+scroll_percentage+"%)" });
$('#logo').css({background: "linear-gradient(to right, "+LoadingEffect+" "+scroll_percentage+"%,"+primary_nav_bg+" "+scroll_percentage+"%)" });


}



jQuery(window).scroll(function() {
scroll_fn();
});

jQuery(window).resize(function() {
scroll_fn();
});

});