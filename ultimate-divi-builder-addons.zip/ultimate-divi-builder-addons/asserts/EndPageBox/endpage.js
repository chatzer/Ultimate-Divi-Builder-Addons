  jQuery(window).load( function($) {
								
		 if( jQuery('body').find('#endpage-box').length >0 ){	 
   
				 jQuery("#endpage-box").endpage_box({
				  animation: "fade",
				  from: "10%",
				  to: "30%"
				});
 		 }	
		 
		  if( jQuery('body').find('#endpage-box2').length >0 ){	 
   
   				jQuery("#endpage-box2").endpage_box({
				  animation: "slide",
				  from: "40%",
				  to: "60%"
				});
	
 		 }
		 
		  if( jQuery('body').find('#endpage-box3').length >0 ){	 
   
				 jQuery("#endpage-box3").endpage_box({
				  animation: false,
				  from: "70%",
				  to: "90%"
				});
	
	
	
 		 }
		 
		  if( jQuery('body').find('#endpage-box4').length >0 ){	 
   
   				 jQuery("#endpage-box4").endpage_box({
					  animation: "flyInLeft",
					  from: "90%",
					  to: "110%"
					});
	
 		 }
		 

	   
	  });
			