jQuery(document).ready(function ($) {
   var slide1 = new DoSlide('.et_pb_section ',{
                infinite: true
            });
  
  
});			
				
				