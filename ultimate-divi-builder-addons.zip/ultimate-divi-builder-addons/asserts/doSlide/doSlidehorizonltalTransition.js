jQuery(document).ready(function ($) {
  
	 if( jQuery('body').find('.doSlidehorizonltalTransition-container').length >0 ){	 
   var slide5 = new DoSlide('.doSlidehorizonltalTransition-container .et_pb_column', {
                duration: 1200,
                timingFunction: 'cubic-bezier(0.25, 0.01, 0.63, 1.7)',
                minInterval: 20,
				horizontal: true,
			    infinite: true
            });
	 }
 
});			
				
				