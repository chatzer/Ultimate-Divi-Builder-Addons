
/**
 * @component fadeIntoView
 * Makes elements with fade-into-view class fade into view when they enter the viewport
 * @note: Relies on elements having a class fade-into-view and a unique id
 * @requires JQuery http://www.jquery.com
 * @requires JQuery Velocity http://julian.com/research/velocity/
 * @author Daniel Ivanovic dan.ivanovic@antiblanks.com
 */
jQuery(document).ready(function($){
    $("body").fadeIntoView({
					"applyBlur": true,
					"hiddenOpacity": 0.6
});
});
