jQuery(document).ready(function ($) {
	var $form  = $('.et-divi-scroll-form');


	// Help box
	$(".box-description").click(function(){
		var descheading = $(this).parent('.epanel-box').find(".box-title h3").html();
		var desctext = $(this).parent('.epanel-box').find(".box-title .box-descr").html();

		$('body').append("<div id='custom-lbox'><div class='box-desc'><div class='box-desc-top'>"+ et_divi_scroll_js_params.help_label +"</div><div class='box-desc-content'><h3>"+descheading+"</h3>"+desctext+"<div class='lightboxclose'></div> </div> <div class='box-desc-bottom'></div>	</div></div>");

		$( '.lightboxclose' ).click( function() {
			et_pb_close_modal( $( '#custom-lbox' ) );
		});
	});

	function et_pb_close_modal( $overlay, no_overlay_remove ) {
		var $modal_container = $overlay;

		// add class to apply the closing animation to modal
		$modal_container.addClass( 'et_pb_modal_closing' );

		//remove the modal with overlay when animation complete
		setTimeout( function() {
			if ( 'no_remove' !== no_overlay_remove ) {
				$modal_container.remove();
			}
		}, 600 );
	}
});