<?php
$is_settings_updated = false;
$nonce   = "scroll_nonce";
if ( isset( $_POST[ $nonce ] ) ) {

	$is_settings_updated         = true;
	$is_settings_updated_success = false;
	// Verify nonce and user permission
	if ( wp_verify_nonce( $_POST[ $nonce ], $nonce ) && current_user_can( 'switch_themes' ) ) {
	
			$scrolloptions		         = $_POST['scrolloptions'];
			$LoadingEffect1color		 = $_POST['LoadingEffect1color'];
			$LoadingEffect2color		 = $_POST['LoadingEffect2color'];
			$LoadingEffect3color		 = $_POST['LoadingEffect3color'];
			$LoadingEffect4color		 = $_POST['LoadingEffect4color'];
			
			
			$fadeintoview		 = $_POST['fadeintoview'];
			$wow		 = $_POST['wow'];
			$scrollmagic_responsive		 = $_POST['scrollmagic_responsive'];
			$scrollmagic_wipes		 = $_POST['scrollmagic_wipes'];
			$scrollreveal		 = $_POST['scrollreveal'];
			
		
			
			$doSlidehorizonltalTransition		 = $_POST['doSlidehorizonltalTransition'];
			
			
			$StickyStack		 = $_POST['StickyStack'];
			$LoadingEffect1		 = $_POST['LoadingEffect1'];
			$LoadingEffect2		 = $_POST['LoadingEffect2'];
			$LoadingEffect3		 = $_POST['LoadingEffect3'];
			$LoadingEffect4		 = $_POST['LoadingEffect4'];
			
			$ScrollFlow		 = $_POST['ScrollFlow'];
			$pagePiling		 = $_POST['pagePiling'];
			$pagePilingh		 = $_POST['pagePilingh'];
			
			$scrollingwindows		 = $_POST['scrollingwindows'];
			
			$scrollfx		 = $_POST['scrollfx'];
			$Revealator		 = $_POST['Revealator'];
			$scrollTrigger		 = $_POST['scrollTrigger'];
			$CustomScrollbar		 = $_POST['CustomScrollbar'];
			$CustomScrollbarEffect8		 = $_POST['CustomScrollbarEffect8'];
			$HideScrollingDown		 = $_POST['HideScrollingDown'];
			$FlippingText		 = $_POST['FlippingText'];
			$SuperEasyTextRotator		 = $_POST['SuperEasyTextRotator'];
			$EndPageBox		 = $_POST['EndPageBox'];
			
			
			
			update_option('divi_scrolloptions',$scrolloptions);
			update_option('LoadingEffect1color',$LoadingEffect1color);
			update_option('LoadingEffect2color',$LoadingEffect2color);
			update_option('LoadingEffect3color',$LoadingEffect3color);
			update_option('LoadingEffect4color',$LoadingEffect4color);

			update_option('fadeintoview',$fadeintoview);
			
			update_option('wow',$wow);
			update_option('scrollmagic_responsive',$scrollmagic_responsive);
			update_option('scrollmagic_wipes',$scrollmagic_wipes);
			update_option('scrollreveal',$scrollreveal);
			
			
			
			update_option('doSlidehorizonltalTransition',$doSlidehorizonltalTransition);
			
			update_option('StickyStack',$StickyStack);
			update_option('LoadingEffect1',$LoadingEffect1);
			update_option('LoadingEffect2',$LoadingEffect2);
			update_option('LoadingEffect3',$LoadingEffect3);
			update_option('LoadingEffect4',$LoadingEffect4);
			
			
			update_option('ScrollFlow',$ScrollFlow);
			update_option('pagePiling',$pagePiling);
			update_option('pagePilingh',$pagePilingh);
			
			update_option('scrollingwindows',$scrollingwindows);
			
			update_option('scrollfx',$scrollfx);
			update_option('Revealator',$Revealator);
			update_option('scrollTrigger',$scrollTrigger);
			update_option('CustomScrollbar',$CustomScrollbar);
			
			
			update_option('HideScrollingDown',$HideScrollingDown);
			update_option('FlippingText',$FlippingText);
			update_option('SuperEasyTextRotator',$SuperEasyTextRotator);
			update_option('EndPageBox',$EndPageBox);
			
			
			$is_settings_updated_message = __( 'Options have been updated.' );
			$is_settings_updated_success = true;
			
			
	} else {
			$is_settings_updated_message = __( 'Error authenticating request. Please try again.' );
	}

}



$LoadingEffect1colorf ='';
$LoadingEffect2colorf ='';
$LoadingEffect3colorf ='';
$LoadingEffect4colorf ='';
 $getscrolloptions = get_option('divi_scrolloptions');
 if ( $getscrolloptions == ''){
 	$getscrolloptions = array("Default");
 }
 $LoadingEffect1colorft = get_option('LoadingEffect1color');
 $LoadingEffect2colorft = get_option('LoadingEffect2color');
 $LoadingEffect3colorft = get_option('LoadingEffect3color');
 $LoadingEffect4colorft = get_option('LoadingEffect4color');
 $toggle_options = array( 'off', 'on' );
?><div id="wrapper" class="et-divi-gradient-form">
				<div id="panel-wrap">
					<?php if ( $is_settings_updated ) { ?>
						<div id="setting-error-settings_updated" class="updated settings-error notice is-dismissible <?php echo $is_settings_updated_success ? '' : 'error' ?>" style="margin: 0 0 25px 0;">
							<p>
								<strong><?php echo esc_html( $is_settings_updated_message ); ?></strong>
							</p>
							<button type="button" class="notice-dismiss">
								<span class="screen-reader-text"><?php _e( 'Dismiss this notice.' ); ?></span>
							</button>
						</div>
					<?php } ?>

					

					
						<div id="epanel-wrapper">
							<div id="epanel">
								<div id="epanel-content-wrap">
									<div id="epanel-content">
									
										<div id="epanel-header" class="scrollplugin">
											<h1 id="epanel-title"><div class="scrollleft"><img src="<?php echo  SE_PATH_URL;?>images/ultimate-divi-317x95.png" width="310" height="95"/></div><div class="scrolltitle">Take the power of Divi builder to next level</div></h1>
										</div><!-- #wrap-general.content-div -->
											<form action="" method="POST" class="et-divi-scroll-form">
										<div id="wrap-general" class="content-div diviscroll">
										
										<div id="tabs" class="scrolltab">
		                                    <?php
											  
											  $fadeview = !empty(get_option('fadeintoview')) ? get_option('fadeintoview') : 'off';
											  $WOW = !empty(get_option('wow')) ? get_option('wow') : 'off';
											  $scrollmagicresponsive = !empty(get_option('scrollmagic_responsive')) ? get_option('scrollmagic_responsive') : 'off';
											  $scrollmagicwipes = !empty(get_option('scrollmagic_wipes')) ? get_option('scrollmagic_wipes') : 'off';
											  $reveal = !empty(get_option('scrollreveal')) ? get_option('scrollreveal') : 'off';
											  $SlidehorizonltalTransition = !empty(get_option('doSlidehorizonltalTransition')) ? get_option('doSlidehorizonltalTransition') : 'off';
											  
											  $Stack = !empty(get_option('StickyStack')) ? get_option('StickyStack') : 'off';
											  $Loading1 = !empty(get_option('LoadingEffect1')) ? get_option('LoadingEffect1') : 'off';
											  $Loading2 = !empty(get_option('LoadingEffect2')) ? get_option('LoadingEffect2') : 'off';
											  $Loading3 = !empty(get_option('LoadingEffect3')) ? get_option('LoadingEffect3') : 'off';
											  $Loading4 = !empty(get_option('LoadingEffect4')) ? get_option('LoadingEffect4') : 'off';
											  
											 
											  $Flow = !empty(get_option('ScrollFlow')) ? get_option('ScrollFlow') : 'off';
											  $Piling = !empty(get_option('pagePiling')) ? get_option('pagePiling') : 'off';
											  $Pilingh = !empty(get_option('pagePilingh')) ? get_option('pagePilingh') : 'off';
											  
											  $windows = !empty(get_option('scrollingwindows')) ? get_option('scrollingwindows') : 'off';
											  $strol = !empty(get_option('stroll')) ? get_option('stroll') : 'off';
											  $fx = !empty(get_option('scrollfx')) ? get_option('scrollfx') : 'off';
											  $Rlator = !empty(get_option('Revealator')) ? get_option('Revealator') : 'off';
											  $Trigger = !empty(get_option('scrollTrigger')) ? get_option('scrollTrigger') : 'off';
											  
											  $Custom = !empty(get_option('CustomScrollbar')) ? get_option('CustomScrollbar') : 'off';
											  
											  $HideDown = !empty(get_option('HideScrollingDown')) ? get_option('HideScrollingDown') : 'off';
											  $Flipping = !empty(get_option('FlippingText')) ? get_option('FlippingText') : 'off';
											  $SuperEasy = !empty(get_option('SuperEasyTextRotator')) ? get_option('SuperEasyTextRotator') : 'off';
											  $EndPage = !empty(get_option('EndPageBox')) ? get_option('EndPageBox') : 'off';
											 
											  
											  ?>
											<ul class="idTabs idscrolltab  mCustomScrollbar CustomScrollbarEffect1b mCustomScrollbarcontent">
													
													
													
													<li class="ui-tabs  ui-tabs-active <?php if( $Custom  == 'on'):?>activeon<?php endif;?>">	<a href="#general-28"><?php _e( 'Custom Scrollbar' ); ?></a></li>
												
													
													
													<li class="ui-tabs <?php if( $SlidehorizonltalTransition == 'on'):?>activeon<?php endif;?>">	<a href="#general-10"><?php _e( 'doSlide Horizontal' ); ?></a></li>
													
													<li class="ui-tabs <?php if( $fadeview == 'on'):?>activeon<?php endif;?>">	<a href="#general-1"><?php _e( 'Fade Into View' ); ?></a></li>
													
													<li class="ui-tabs <?php if( $Flipping  == 'on'):?>activeon<?php endif;?>">	<a href="#general-39"><?php _e( 'Flipping Text' ); ?></a></li>
													<li class="ui-tabs <?php if( $HideDown  == 'on'):?>activeon<?php endif;?>">	<a href="#general-38"><?php _e( 'Hide the Divi Theme Header when Scrolling Down' ); ?></a></li>
													
													
													<li class="ui-tabs <?php if( $Piling == 'on'):?>activeon<?php endif;?>">	<a href="#general-20"><?php _e( 'jQuery pagePiling Vertical Scroll' ); ?></a></li>
													<li class="ui-tabs <?php if( $Pilingh == 'on'):?>activeon<?php endif;?>">	<a href="#general-99"><?php _e( 'jQuery pagePiling Horizontal Scroll' ); ?></a></li>
													
													<li class="ui-tabs <?php if( $Flow == 'on'):?>activeon<?php endif;?>">	<a href="#general-19"><?php _e( 'jQuery ScrollFlow' ); ?></a></li>
													
													<li class="ui-tabs <?php if( $fx  == 'on'):?>activeon<?php endif;?>">	<a href="#general-25"><?php _e( 'jQuery scrollfx' ); ?></a></li>
													<li class="ui-tabs <?php if( $Trigger  == 'on'):?>activeon<?php endif;?>">	<a href="#general-27"><?php _e( 'jQuery scrollTrigger' ); ?></a></li>
													<li class="ui-tabs <?php if( $EndPage  == 'on'):?>activeon<?php endif;?>">	<a href="#general-41"><?php _e( 'jQuery End Page Box' ); ?></a></li>
													<li class="ui-tabs <?php if( $Loading1 == 'on'):?>activeon<?php endif;?>">	<a href="#general-14"><?php _e( 'Loading Header while Scrolling Effect1' ); ?></a></li>
													<li class="ui-tabs <?php if( $Loading2 == 'on'):?>activeon<?php endif;?>">	<a href="#general-15"><?php _e( 'Loading Header while Scrolling Effect2' ); ?></a></li>
													<li class="ui-tabs <?php if( $Loading3 == 'on'):?>activeon<?php endif;?>">	<a href="#general-16"><?php _e( 'Loading Header while Scrolling Effect3' ); ?></a></li>
													<li class="ui-tabs <?php if( $Loading4 == 'on'):?>activeon<?php endif;?>">	<a href="#general-86"><?php _e( 'Loading Header while Scrolling Effect4' ); ?></a></li>
													
													<li class="ui-tabs <?php if( $Rlator  == 'on'):?>activeon<?php endif;?>">	<a href="#general-26"><?php _e( 'Revealator Animation' ); ?></a></li>
													
													<li class="ui-tabs <?php if( $scrollmagicresponsive == 'on'):?>activeon<?php endif;?>">	<a href="#general-3"><?php _e( 'ScrollMagic Responsive Duration' ); ?></a></li>
													<li class="ui-tabs <?php if( $scrollmagicwipes == 'on'):?>activeon<?php endif;?>">	<a href="#general-4"><?php _e( 'ScrollMagic Section Wipes' ); ?></a></li>
													<li class="ui-tabs <?php if( $reveal == 'on'):?>activeon<?php endif;?>">	<a href="#general-43"><?php _e( 'ScrollReveal' ); ?></a></li>
												
													<li class="ui-tabs <?php if( $Stack == 'on'):?>activeon<?php endif;?>">	<a href="#general-13"><?php _e( 'StickyStack : jQuery Stacking Effect' ); ?></a></li>
													
													<li class="ui-tabs <?php if( $windows  == 'on'):?>activeon<?php endif;?>">	<a href="#general-23"><?php _e( 'Scrolling windows' ); ?></a></li>
													
													
													<li class="ui-tabs <?php if( $SuperEasy  == 'on'):?>activeon<?php endif;?>">	<a href="#general-40"><?php _e( 'Super Simple Text Rotator/Ticker' ); ?></a></li>
													
													
													
													
													
													<li class="ui-tabs <?php if( $WOW == 'on'):?>activeon<?php endif;?>">	<a href="#general-2"><?php _e( 'WOW Animation' ); ?></a></li>
										
											</ul><!-- .idTabs -->
											
											
											
											
											<div id="general-1" class="tab-content">
													
												 <div class="epanel-box" data-type="toggle">
														     
															  <div class="box-content">
																	<b> Fade Into View</b>
																	 <br/><br/>
																	  <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'fadeintoview' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_fadeintoview = !empty(get_option('fadeintoview')) ? get_option('fadeintoview') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_fadeintoview ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_fadeintoview ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?>
																	 <br/> <br/>	
																	 
																	 <p>Make elements fade in and out of view when they enter/exit the window<br/><br/>
																	 <b>How to use:</b> <br/> <br/>
																      Add class "fade-into-view" into Section or Row or Module <br/><br/>
																	  <b>Source:</b> 
																	  <a href="http://www.jqueryscript.net/animation/jQuery-Plugin-To-Make-Elements-Fade-Into-View-When-Entering-Viewport.html" target="_blank">  http://www.jqueryscript.net/animation/jQuery-Plugin-To-Make-Elements-Fade-Into-View-When-Entering-Viewport.html</a>
																	 </p>
																	
												   			   </div>	
															   
										         </div><!-- .epanel-box -->
											</div>
											
											
											<div id="general-2" class="tab-content" >
												   
												   <div class="epanel-box" data-type="toggle">
												  			   
															
															  <div class="box-content">
																 	<b>WOW Animation</b><br/><br/>
																	  <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'wow' ),esc_attr( '200' ),esc_attr( '200' ));
																				
																	  $selected_value_wow = !empty(get_option('wow')) ? get_option('wow') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_wow ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_wow ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?>
																	 <br/> <br/>		
																
																<p>CSS animations as you scroll down a page. You can animate any Divi module with this effect.<br/><br/>
																
																<b>How to use WOW Animation </b> <br/> <br/>
																Add class "wow" with below classes into Row or Section or a Module. <br/><br/> 		
																Example : "wow bounce" , "wow swing" , "wow bounceInDown" etc..<br/><br/>
																
																
																	bounce<br/>flash<br/>pulse<br/>rubberBand<br/>shake<br/>headShake<br/>
																	swing<br/>tada<br/>wobble<br/>jello<br/>bounceIn<br/>bounceInDown<br/>
																	bounceInLeft<br/>bounceInRight<br/>bounceInUp<br/>bounceOut<br/>
																	bounceOutDown<br/>bounceOutLeft<br/>bounceOutRight<br/>bounceOutUp<br/>
																	fadeIn<br/>fadeInDown<br/>fadeInDownBig<br/>fadeInLeft<br/>fadeInLeftBig<br/>
																	fadeInRight<br/>fadeInRightBig<br/>fadeInUp<br/>fadeInUpBig<br/>
																	fadeOut<br/>fadeOutDown<br/>fadeOutDownBig<br/>fadeOutLeft<br/>
																	fadeOutLeftBig<br/>fadeOutRight<br/>fadeOutRightBig<br/>fadeOutUp<br/>
																	fadeOutUpBig<br/>flipInX<br/>flipInY<br/>flipOutX<br/>flipOutY<br/>
																	lightSpeedIn<br/>lightSpeedOut<br/>rotateIn<br/>rotateInDownLeft<br/>rotateInDownRight<br/>
																	rotateInUpLeft<br/>rotateInUpRight<br/>rotateOut<br/>rotateOutDownLeft<br/>rotateOutDownRight<br/>
																	rotateOutUpLeft<br/>rotateOutUpRight<br/>hinge<br/>rollIn<br/>rollOut<br/>zoomIn<br/>zoomInDown<br/>
																	zoomInLeft<br/>zoomInRight<br/>zoomInUp<br/>zoomOut<br/>zoomOutDown<br/>zoomOutLeft<br/>
																	zoomOutRight<br/>zoomOutUp<br/>slideInDown<br/>slideInLeft<br/>slideInRight<br/>slideInUp<br/>
																	slideOutDown<br/>slideOutLeft<br/>slideOutRight<br/>slideOutUp<br/><br/>
																	<b>Note : <br/> <br/>

If you want to use image module with this effect then please set "Animation" option to "No Animation" <br/> <br/>

Works best with Rows and Modules <br/> <br/>

All of these CSS classes are working in custom HTML code, Text Module and Code Module <br/> <br/>

Advanced settings you can use with WOW Animation classes, <br/> <br/>
-	data-wow-duration: Change the animation duration <br/> <br/>
-	data-wow-delay: Delay before the animation starts <br/> <br/>
-	data-wow-offset: Distance to start the animation (related to the browser bottom) <br/> <br/>
-	data-wow-iteration: Number of times the animation is repeated
</b><br/><br/>
																		  <b>Source:</b> 
																	  <a href="https://github.com/matthieua/WOW" target="_blank">  https://github.com/matthieua/WOW</a>
																</p>
												     </div>
															  
																
											  </div><!-- .epanel-box -->
											</div>	
											<div id="general-3" class="tab-content">	
													 <div class="epanel-box"   data-type="toggle">
														      <!-- .box-title -->
															   <div class="box-content">
																	<b>ScrollMagic Responsive Duration</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'scrollmagic_responsive' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_scrollmagic_responsive = !empty(get_option('scrollmagic_responsive')) ? get_option('scrollmagic_responsive') : 'off'; 
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_scrollmagic_responsive ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_scrollmagic_responsive ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?>
																		
																<br /><br />		
																
																	<p>This effect works best with Button or Call to Action modules. It creates nice zoom in and out animation to these modules as the user scroll through the page. Scene duration depending on viewport size.</p><br/>
																	<b>Stpes:</b><br /><br />
a) Add Button or Call to Action module from Divi builder (You can animate almost any module)<br /><br />
b) Add Class "responsive-duration-trigger" on a Section/Row/Module<br /><br />
c) Add Class "responsive-duration-animate" on the Module you want to animate.<br /><br />

<b> Note: Use the section right above the module you want to animate as the trigger</b><br /><br />
																<br /> <b>Source:</b> 
																	  <a href="http://scrollmagic.io/examples/basic/responsive_duration.html" target="_blank"> http://scrollmagic.io/examples/basic/responsive_duration.html</a>
																</p>
																
															   </div>	
															    
												   </div><!-- .epanel-box -->
											</div>	   
											<div id="general-4" class="tab-content">	   
												    
												   
												   
												    <div class="epanel-box"   data-type="toggle">
														     
															  <!-- .box-title -->
															  <div class="box-content">
																	<b> ScrollMagic Section Wipes </b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'scrollmagic_wipes' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_scrollmagic_wipes = !empty(get_option('scrollmagic_wipes')) ? get_option('scrollmagic_wipes') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_scrollmagic_wipes ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_scrollmagic_wipes ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?>
																<br /><br />		
																Wiping in content with the natural scroll movement<br /><br />
																<b>Stpes:</b><br /><br />
																a) Add Class "section-wipes-panel" on Section.<br /><br />
																
																<b>Note:<br /><br />
Use this CSS class from second section onwards<br /><br />
You may want to activate 'Hide Divi Theme Header when scrolling' to make this effect appear better
</b><br /><br /> 
<b>Source:</b> 
																	  <a href="http://scrollmagic.io/examples/basic/section_wipes_natural.html" target="_blank"> http://scrollmagic.io/examples/basic/section_wipes_natural.html</a>
																</p>
																
												      </div>	
															  
												   </div><!-- .epanel-box -->
												   
												</div>	   
											<div id="general-43" class="tab-content">   
												   
												  <div class="epanel-box"   data-type="toggle">
														     
															  <!-- .box-title -->
																<div class="box-content">
																	<b>ScrollReveal</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'scrollreveal' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_scrollreveal = !empty(get_option('scrollreveal')) ? get_option('scrollreveal') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_scrollreveal ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_scrollreveal ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br/><br/>
																 <p>Reveal modules on scroll. These animations works both page scroll up and down<br/><br/>
																 
																 <b>How to use:</b><br/><br/>
																 Add class "scrollreveal" into Row or Section or Module<br/><br/>
																  Add class "scrollreveal1" into Row or Section or Module <br/><br/>
																  
																Add class "scrollrevealEffect1" into Row or Section or Module<br/><br/> 
																Add class "scrollrevealEffect1a" into Row or Section or Module<br/><br/> 
																Add class "scrollrevealEffect1b" into Row or Section or Modulee<br/><br/> 
																Add class "scrollrevealEffect1c" into Row or Section or Module<br/><br/> 
																Add class "scrollrevealEffect1d" into Row or Section or Module<br/><br/>
																Add class "scrollrevealEffect1e" into Row or Section or Module<br/><br/> 
																Add class "scrollrevealEffect1f" into Row or Section or Module<br/><br/>
																Add class "scrollrevealEffect1g" into Row or Section or Module<br/><br/>
																
																Add class "scrollrevealEffect2" into Row or Section or Module <br/><br/>
																Add class "scrollrevealEffect3" into Row or Section or Module <br/><br/>
																Add class "scrollrevealEffect4" into Row or Section or Module <br/><br/>
																Add class "scrollrevealEffect5" into Row or Section or Module <br/><br/>
																Add class "scrollrevealEffect6" into Row or Section or Module <br/><br/>
																Add class "scrollrevealEffect7" into Row or Section or Module <br/><br/>
																Add class "scrollrevealEffect8" into Row or Section or Module <br/><br/>
																<b>Source:</b> 
																	  <a href="https://github.com/jlmakes/scrollreveal
" target="_blank"> https://github.com/jlmakes/scrollreveal</a>
																  </p>
															   </div>	
															  
												   </div><!-- .epanel-box -->
										</div>	   
											
												   
												   
												   
												   
											<div id="general-10" class="tab-content">	   
												   
												  <div class="epanel-box"   data-type="toggle">
														     
															
															   <div class="box-content">
															   <b>doSlide Horizontal</b>
															   <br/><br/>
																	<?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'doSlidehorizonltalTransition' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_doSlidehorizonltalTransition = !empty(get_option('doSlidehorizonltalTransition')) ? get_option('doSlidehorizonltalTransition') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_doSlidehorizonltalTransition ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_doSlidehorizonltalTransition ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br /><br />
																<p> 
DoSlide is a javascrit library for full-page section scroll or horizontal slider. You can use this to have scrolling effect inside a Divi builder section. With each mouse scroll user can navigate next modules inside a row. This effect is touch enabled so it works well with mobile devices. The user can scroll through modules in the same section without having to scroll the entire page.<br /><br />
 <b>How to use:</b><br/><br/>
1. Add Class "doSlidehorizonltalTransition-parent" on Section.<br /><br /> 

2. Add Class "doSlidehorizonltalTransition-container" on Row.<br /><br /> 

3. Multiple Modules on Row - one module per a Column.  <br /><br />
<b>Note: <br /><br />
Remove any module animations - If you are using Image module make it 'No Animation'<br /><br />
Use 1280 width images for best visibility<br /><br />
Apart form the Text module other modules are not optimized for mobile display<br /><br />
</b>

																</p>	<b>Source:</b> 
																	  <a href="https://github.com/MopTym/doSlide
" target="_blank"> https://github.com/MopTym/doSlide</a> , <a href="https://github.com/MopTym/doSlide/tree/dev/demo
" target="_blank"> https://github.com/MopTym/doSlide/tree/dev/demo</a>

												     </div>	
												   </div><!-- .epanel-box -->
												   <!-- .epanel-box -->
											</div>	   
												   
												 
											  
												   
											<div id="general-13" class="tab-content">	   
												  <div class="epanel-box"   data-type="toggle">
														     
															  
																<div class="box-content">
																	<b>jQuery Stacking Effect</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'StickyStack' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_StickyStack = !empty(get_option('StickyStack')) ? get_option('StickyStack') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_StickyStack ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_StickyStack ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br /> <br />
																	 A jQuery effect that creates a stacking effect by sticking panels as they reach the top of the viewport.<br /> <br /> 
<b>How to use:</b><br /> <br />
1. Add Class "et_pb_section_sticky" on any Section on the page<br /> <br />
<b>Note:<br /> <br />
When you add this class, the stacking effect happen to all sections of the page<br /> <br />
You may want to activate 'Hide Divi Theme Header when scrolling' to make this effect appear better<br /> <br />
There's a conflict with Divi slider module 

</b><br /> <br />
 </p><b>Source:</b> 
																	  <a href="https://codepen.io/mike-zarandona/full/Dasnw
" target="_blank"> https://codepen.io/mike-zarandona/full/Dasnw</a> 
															   </div>	
															   
												   </div><!-- .epanel-box -->
											</div>	   
											<div id="general-14" class="tab-content">	   
												    <div class="epanel-box"   data-type="toggle">
														     
															  
																<div class="box-content">
																	<b>Loading Header while Scrolling with jQuery & CSS3</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'LoadingEffect1' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_LoadingEffect1 = !empty(get_option('LoadingEffect1')) ? get_option('LoadingEffect1') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_LoadingEffect1 ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_LoadingEffect1 ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br /> <br /> 
																	Choose Color : <input id="LoadingEffect1color" name="LoadingEffect1color" value="<?php echo $LoadingEffect1colorft;?>"  type="text">
																	 
																	
																	<?php if($selected_value_LoadingEffect1 == 'on'):?><script> var colorString ="<?php echo $LoadingEffect1colorft;?>";jQuery("#LoadingEffect1color").spectrum("set", colorString);
																	</script><?php endif;?><br/><br/>
																	<p> Create a loading header effect while you scroll. </p><br />
																	<b>Note: This effect don't work when you activate 'Hide Navigation Until Scroll'</b><br /><br /> <b>Source:</b> 
																	  <a href="http://www.jqueryrain.com/2015/03/loading-header-scrolling-jquery-css3/" target="_blank"> http://www.jqueryrain.com/2015/03/loading-header-scrolling-jquery-css3/</a> 
															   </div>	
												   </div><!-- .epanel-box -->
											</div>	   
											
											<div id="general-15" class="tab-content">	   
												   <div class="epanel-box"   data-type="toggle">
														     
																<div class="box-content">
																	<b>Loading Header while Scrolling with jQuery & CSS3</b><br/><br/>
																	
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'LoadingEffect2' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_LoadingEffect2 = !empty(get_option('LoadingEffect2')) ? get_option('LoadingEffect2') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_LoadingEffect2 ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_LoadingEffect2 ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br /><br />
																     
																	Choose Color : <input id="LoadingEffect2color" name="LoadingEffect2color" value="<?php echo $LoadingEffect2colorft;?>"  type="text">
																	<br /><br />  <?php if($selected_value_LoadingEffect2 == 'on'):?>
																	<script> var colorString2 ="<?php echo $LoadingEffect2colorft;?>";jQuery("#LoadingEffect2color").spectrum("set", colorString2);
																	</script> 
																	 <?php endif;?>
																	 <p> Create a loading header effect while you scroll. </p><br /><br />
																	 
																	 <b>Note:The menu background becomes full White color and gets filled with plugin defined color</b><br /><br /><b>Source:</b> 
																	  <a href="http://www.jqueryrain.com/2015/03/loading-header-scrolling-jquery-css3/" target="_blank"> http://www.jqueryrain.com/2015/03/loading-header-scrolling-jquery-css3/</a> 
															   </div>	
												   </div><!-- .epanel-box -->
											</div>	   
											
											
											<div id="general-16" class="tab-content">	   
												   <div class="epanel-box"   data-type="toggle">
														     
															  
																<div class="box-content">
																	
																	  
																	<b>Loading Header while Scrolling with jQuery & CSS3</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'LoadingEffect3' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_LoadingEffect3 = !empty(get_option('LoadingEffect3')) ? get_option('LoadingEffect3') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_LoadingEffect3 ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_LoadingEffect3 ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br /><br />
																	 
																	Choose Color : <input id="LoadingEffect3color" name="LoadingEffect3color" value="<?php echo $LoadingEffect3colorft;?>"  type="text">
																	<br /><br /> <?php if($selected_value_LoadingEffect3 == 'on'):?>
																	<script> var colorString3 ="<?php echo $LoadingEffect3colorft;?>";jQuery("#LoadingEffect3color").spectrum("set", colorString3);
																	</script> 
																	 <?php endif;?>
																	 <p> Create a loading header effect while you scroll. </p><br /><br />
																	 
																	 <b>Note:The logo background section becomes white</b><br /><br /><b>Source:</b> 
																	  <a href="http://www.jqueryrain.com/2015/03/loading-header-scrolling-jquery-css3/" target="_blank"> http://www.jqueryrain.com/2015/03/loading-header-scrolling-jquery-css3/</a> 
															   </div>	
												   </div><!-- .epanel-box -->
											</div>	    
											
											
											<div id="general-86" class="tab-content">	   
												   <div class="epanel-box"   data-type="toggle">
														     
															  
																<div class="box-content">
																	
																	  
																	<b>Loading Header while Scrolling with jQuery & CSS3</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'LoadingEffect4' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_LoadingEffect4 = !empty(get_option('LoadingEffect4')) ? get_option('LoadingEffect4') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_LoadingEffect4 ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_LoadingEffect4 ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br /><br />
																	 
																	Choose Color : <input id="LoadingEffect4color" name="LoadingEffect4color" value="<?php echo $LoadingEffect4colorft;?>"  type="text">
																	<br /><br /> <?php if($selected_value_LoadingEffect4 == 'on'):?>
																	<script> var colorString4 ="<?php echo $LoadingEffect4colorft;?>";jQuery("#LoadingEffect4color").spectrum("set", colorString4);
																	</script> 
																	 <?php endif;?>
																	 <p> Create a loading header effect while you scroll. </p><br /><br />
																	 
																	 <b>Note:The logo background section becomes white</b><br /><br /><b>Source:</b> 
																	  <a href="http://www.jqueryrain.com/2015/03/loading-header-scrolling-jquery-css3/" target="_blank"> http://www.jqueryrain.com/2015/03/loading-header-scrolling-jquery-css3/</a> 
															   </div>	
												   </div><!-- .epanel-box -->
											</div>
											
												   
											<div id="general-19" class="tab-content">	   
												   
												   <div class="epanel-box" data-type="toggle">
														     
															  
																<div class="box-content">
																	<b>jQuery ScrollFlow</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'ScrollFlow' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_ScrollFlow = !empty(get_option('ScrollFlow')) ? get_option('ScrollFlow') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_ScrollFlow ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_ScrollFlow ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br/><br/>
																
<b>Nice scroll animations to add to any Divi Module or Row.. These animations works both page scroll up and down.</b> <br/><br/>
<b>How to use:</b> <br/><br/>
Add Class "scrollflow -pop -opacity" on Section or Row or Module.<br/><br/>
Add Class "scrollflow -slide-right -opacity" on Section or Row or Module.<br/><br/>
Add Class "scrollflow -slide-left -opacity" on Section or Row or Module.<br/><br/>
Add Class "scrollflow -slide-top -opacity" on Section or Row or Module.<br/><br/>
Add Class "scrollflow -slide-bottom -opacity" on Section or Row or Module.<br/><br/>

<b>Note : Works best when used with modules.</b> <br/><br/>
<b>Source:</b> 
																	  <a href="http://www.cwdesigns.de/jquery-scrollflow-plugin.html" target="_blank"> http://www.cwdesigns.de/jquery-scrollflow-plugin.html</a> 
															   </div>	
												   </div><!-- .epanel-box -->
											</div>	   
											<div id="general-20" class="tab-content">	   
												  <div class="epanel-box"   data-type="toggle">
														     
															  
																<div class="box-content">
																	 <b>jQuery pagePiling Vertical scroll</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'pagePiling' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_pagePiling = !empty(get_option('pagePiling')) ? get_option('pagePiling') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_pagePiling ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_pagePiling ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?> <br/> <br/>
																
This effect creates scrolling stack of pages. This a new way to create a single scrolling page in which sections are piled one over another creating an original effect to present the information. You can use this effect to showcase your image gallery in a very attractive way. This effect creates vertical scrolling for each section that has the CSS class.






<br/> <br/>
<b>How to use:</b>   <br/> <br/>
Add Class "et_pb_section_pagepiling" on Sections you want to have this effect.<br/> <br/>
<b>Note: <br/> <br/>

Use single module inside a section for best results <br/> <br/>

This is the effect to use if you want to build a one page scrolling page like 'tumblr'. This effect does not work well with some Divi modules. So, give a test run and check. Don't activate jQuery pagePiling Vertical scroll and jQuery pagePiling Horizontal Scroll at the same time. It creates conflicts <br/> <br/>

This effect makes a section full width and full height

 </b> <br/> <br/>
	<b>Source:</b> 
																	  <a href="http://www.alvarotrigo.com/pagePiling/" target="_blank"> http://www.alvarotrigo.com/pagePiling/</a> 
															   </div>	
												   </div><!-- .epanel-box -->
											</div>	   
												   
											
											<div id="general-99" class="tab-content">	   
												  <div class="epanel-box"   data-type="toggle">
														     
															  
																<div class="box-content">
																	 <b>jQuery pagePiling Horizontal Scroll</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'pagePilingh' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_pagePilingh = !empty(get_option('pagePilingh')) ? get_option('pagePilingh') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_pagePilingh ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_pagePilingh ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?> <br/> <br/>
																

This effect creates scrolling stack of pages. This a new way to create a single scrolling page in which sections are piled one over another creating an original effect to present the information. You can use this effect to showcase your image gallery in a very attractive way. This effect creates horizontal scrolling for each section that has the CSS class. 


<br/> <br/>
<b>How to use:</b>   <br/> <br/>
Add Class "et_pb_section_pagepiling" on Sections you want to have this effect.<br/> <br/>

<b>Note:  <br/> <br/>


Use single module inside a section for best results<br/> <br/>

Don't activate jQuery pagePiling Vertical scroll and jQuery pagePiling Horizontal Scroll at the same time. It creates conflicts<br/> <br/>

This effect makes a section full width and full height
<br/> <br/></b>


	<b>Source:</b> 
																	  <a href="http://www.alvarotrigo.com/pagePiling/" target="_blank"> http://www.alvarotrigo.com/pagePiling/</a> 
															   </div>	
												   </div><!-- .epanel-box -->
											</div>	
											
											  
											<div id="general-23" class="tab-content">	   
												    <div class="epanel-box"   data-type="toggle">
														     
																<div class="box-content">
																	<b>Scrolling windows</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'scrollingwindows' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_scrollingwindows = !empty(get_option('scrollingwindows')) ? get_option('scrollingwindows') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_scrollingwindows ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_scrollingwindows ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br /><br />
																	
A handy, loosely-coupled jQuery effect for full-screen scrolling windows. By using this effect you can have your visitor focus on particular sections of the page. The user can scroll through the page but at the end it will always come back to the nearest section where "window" CSS class is held.<br /><br />
<b>How to use:</b><br /><br />
Add class "window" on Section .<br /><br />
	<b>Source:</b> 
																	  <a href="https://github.com/demsking/one-page-windows" target="_blank"> https://github.com/demsking/one-page-windows</a> 
															   </div>	
												   </div><!-- .epanel-box -->
											</div>	   
												   
											<div id="general-25" class="tab-content">		   
												    <div class="epanel-box"   data-type="toggle">
														     
															  <!-- .box-title -->
																<div class="box-content">
																<b>jQuery scrollfx</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'scrollfx' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_scrollfx = !empty(get_option('scrollfx')) ? get_option('scrollfx') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_scrollfx ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_scrollfx ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br/><br />
																
Scrollfx is a jQuery effect for smooth scroll-triggered animations that allows scaling text and changing the background's opacity as you scroll pass them.<br/><br /> 
<b>How to use:</b> <br/><br />
Add Class "scrollfx" on section.<br/><br />
<b>Note:<br/><br />

Works best with single Row on a Section. Don't add too many Rows<br/><br /></b>

																	<b>Source:</b> 
																	  <a href="https://github.com/marksten/jquery.scrollfx" target="_blank"> https://github.com/marksten/jquery.scrollfx</a> 
																	
															   </div>	
												   </div><!-- .epanel-box -->
											</div>	   
											<div id="general-26" class="tab-content">	   
												    <div class="epanel-box"   data-type="toggle">
														     
															  
																<div class="box-content">
																	<b>jQuery - Revealator</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'Revealator' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_Revealator = !empty(get_option('Revealator')) ? get_option('Revealator') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_Revealator ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_Revealator ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br /><br />
																	
																	<p>Viewport Triggered Element Animations. These animations works both page scroll up and down.<br /><br />
		
<b>How to use:</b><br /><br />
																Add Class "revealator-fade revealator-duration10" OR "revealator-fade revealator-delay2 revealator-duration10" OR "revealator-fade revealator-delay4 revealator-duration10" OR "revealator-fade revealator-delay6 revealator-duration10" on  Sections or Rows or Modules.<br /><br />
																
																Add Class "revealator-rotateleft" OR "revealator-rotateleft revealator-delay1" OR "revealator-rotateleft revealator-delay2" OR "revealator-rotateleft revealator-delay3" on Sections or Rows or Modules.<br /><br />
																
																Add Class "revealator-rotateright" OR "revealator-rotateright revealator-delay1" OR "revealator-rotateright revealator-delay2" OR "revealator-rotateright revealator-delay3" on Sections or Rows or Modules.<br /><br />
																
																Add Class "revealator-slideleft" OR "revealator-slideleft revealator-delay2" OR "revealator-slideleft revealator-delay4" OR "revealator-slideleft revealator-delay6" on Sections or Rows or Modules.<br /><br />
																
																Add Class "revealator-slideright" OR "revealator-slideright revealator-delay2" OR "revealator-slideright revealator-delay4" OR "revealator-slideright revealator-delay6" on Sections or Rows or Modules.<br /><br />
																
																Add Class "revealator-slideup" OR "revealator-slideup revealator-delay1" OR "revealator-slideup revealator-delay2" OR "revealator-slideup revealator-delay3" on  Sections or Rows or Modules.<br /><br />
																
																Add Class "revealator-slidedown revealator-once" OR "revealator-slidedown revealator-once revealator-delay1" OR "revealator-slidedown revealator-once revealator-delay2" OR "revealator-slidedown revealator-once revealator-delay3" on  Sections or Rows or Modules.<br /><br />
																
																Add Class "revealator-zoomin" OR "revealator-zoomin revealator-delay1"  OR "revealator-zoomin revealator-delay2" OR "revealator-zoomin revealator-delay3"  on  Sections or Rows or Modules.<br /><br />
																
																Add Class "revealator-zoomout" OR "revealator-zoomout revealator-delay1"  OR "revealator-zoomout revealator-delay2" OR "revealator-zoomout revealator-delay3"  on  Sections or Rows or Modules.<br /><br />
																
																 </p>
																 <b>Note: For best results use these classes on Modules</b><br /><br />
																 <b>Source:</b> 
																	  <a href="https://github.com/FaroeMedia/revealator" target="_blank"> https://github.com/FaroeMedia/revealator</a> 
															   </div>	
												   </div><!-- .epanel-box -->
										</div>	   
											<div id="general-27" class="tab-content">		   
												    <div class="epanel-box"   data-type="toggle">
														     
																<div class="box-content">
																	<b>jQuery scrollTrigger</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'scrollTrigger' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_scrollTrigger = !empty(get_option('scrollTrigger')) ? get_option('scrollTrigger') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_scrollTrigger ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_scrollTrigger ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br /><br />
																	
Animate any Divi module with nice slide in animation. This works with both page scroll up and down


<br /><br />
<b>How to use: </b><br /><br />

Add Class "scrollTriggerdiv" on section.<br /><br />
<b>Source:</b> 
																	  <a href="https://github.com/terwanerik/ScrollTrigger" target="_blank"> https://github.com/terwanerik/ScrollTrigger</a> 
															   </div>	
												   </div><!-- .epanel-box -->
										    </div>	   
											<div id="general-28" class="tab-content">		   
												  

												   <div class="epanel-box"   data-type="toggle">
														     
																<div class="box-content">
																	<b>CustomScrollbar Effect</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'CustomScrollbar' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_CustomScrollbar = !empty(get_option('CustomScrollbar')) ? get_option('CustomScrollbar') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_CustomScrollbar ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_CustomScrollbar ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br /><br />
																	<p> 
																	By activating this effect and giving below classes you can put scroll bars to a Divi section.<br /><br />
																 <b>How to use:</b><br /><br />
																 
																Add Class "mCustomScrollbar mCustomScrollbarcontent" on Section or Row or Module.<br /><br />
																Add Class "CustomScrollbarEffect1 mCustomScrollbarcontent" on Section or Row or Module.<br /><br />
																Add Class "CustomScrollbarEffect2 mCustomScrollbarcontent" on Section or Row or Module.<br /><br />
																Add Class "CustomScrollbarEffect3 mCustomScrollbarcontent" on Section or Row or Module.<br /><br />
																Add Class "CustomScrollbarEffect4 mCustomScrollbarcontent" on Section or Row or Module.<br /><br />
																Add Class "CustomScrollbarEffect5 mCustomScrollbarcontent" on Section or Row or Module.<br /><br />
																Add Class "CustomScrollbarEffect6 mCustomScrollbarcontent" on Section or Row or Module.<br /><br />
																Add Class "CustomScrollbarEffect7 mCustomScrollbarcontent" on Section or Row or Module.<br /><br />
																 </p><b>Source:</b> 
																	    <a href="http://manos.malihu.gr/repository/custom-scrollbar/demo/examples/complete_examples.html" target="_blank"> http://manos.malihu.gr/repository/custom-scrollbar/demo/examples/complete_examples.html</a> 
																	
															   </div>	
												   </div><!-- .epanel-box -->
												   
											</div>	   
												   
												   
											<div id="general-38" class="tab-content">

													<div class="epanel-box"   data-type="toggle">
														     
																<div class="box-content">
																	<b> Hide the Divi Theme Header when Scrolling Down</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'HideScrollingDown' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_HideScrollingDown = !empty(get_option('HideScrollingDown')) ? get_option('HideScrollingDown') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_HideScrollingDown ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_HideScrollingDown ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br/><br/>
																	
																	
															   </div>	
												   </div><!-- .epanel-box -->
											</div>	   
											<div id="general-39" class="tab-content">   
												   <div class="epanel-box"   data-type="toggle">
														     <div class="box-content">
																	 <b>Flipping Text</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'FlippingText' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_FlippingText = !empty(get_option('FlippingText')) ? get_option('FlippingText') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_FlippingText ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_FlippingText ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br/><br/>
Add real time typing animation to Divi text module. It creates a ticking intro animation for your typography. <br/><br/>
<b>How to use:</b><br/><br/>
Add Class "flippingtext" on Text Module. <br/><br/>
Add Class "flippingtexte1" on Text Module. <br/><br/>
Add Class "flippingtexte2" on Text Module. <br/><br/>
Add Class "flippingtexte3" on Text Module. <br/><br/>
Add Class "flippingtexte4" on Text Module. <br/><br/>
<b>Note: You can adjust the font from Advanced Design Tab of the Text module. </b> <br/><br/>
<b>Source:</b> 
																	  <a href="https://github.com/peachananr/flipping_text" target="_blank"> https://github.com/peachananr/flipping_text</a> 
																 </div>	
												   </div><!-- .epanel-box -->
											</div>	   
											<div id="general-40" class="tab-content">	   
												   <div class="epanel-box"   data-type="toggle">
														     
															  
																<div class="box-content">
																	<b>jQuery Super Easy Text Rotator</b><br/><br/>
																	 <?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'SuperEasyTextRotator' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_SuperEasyTextRotator = !empty(get_option('SuperEasyTextRotator')) ? get_option('SuperEasyTextRotator') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_SuperEasyTextRotator ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_SuperEasyTextRotator ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br/><br/>
																
																<p>Add a super simple rotating/ticking text to your website with little to no markup  <br /><br />
																<b>How to use:</b><br/><br/>
																1. Add below class on module<br /><br />
																Add Class "simpletextrotator" on Module.<br /><br />
																Add Class "simpletextrotatore1" on Module.<br /><br />
																Add Class "simpletextrotatore2" on Module.<br /><br />
																Add Class "simpletextrotatore3" on Module.<br /><br />
																Add Class "simpletextrotatore4" on Module.<br /><br />
																2. Add Class "rotate" using Span tag.<br /><br />
																For Example<br />
																 &lt;h1 class="simpletextrotatore3"&gt;<b>Super &lt;span class="rotate"&gt;Simple, Customizable, Light Weight, Easy&lt;/span&gt; Text Rotator with Style</b>&lt;/h1&gt;<br /><br />
																<b>Note: You can use these animations to any Divi module that has text field<br /><br />
Use commas (,) to rotate texts inside span class
</b><br /><br />
																</p><b>Source:</b> 
																	  <a href="http://www.thepetedesign.com/demos/jquery_super_simple_text_rotator_demo.html" target="_blank"> http://www.thepetedesign.com/demos/jquery_super_simple_text_rotator_demo.html</a> 	
															   </div>	
												   </div><!-- .epanel-box -->
												</div>	   
											<div id="general-41" class="tab-content">   
												   
												 <div class="epanel-box"   data-type="toggle">  
												     
																<div class="box-content">
																	 <b>jQuery End Page Box </b> <br/><br/>
																	<?php 
																	 printf('<select name="%1$s" id="%1$s" data-preview-prefix="%2$s" data-preview-height="%3$s" class="et-pb-toggle-select">',esc_attr( 'EndPageBox' ),esc_attr( '200' ),esc_attr( '200' ));

																	  $selected_value_EndPageBox = !empty(get_option('EndPageBox')) ? get_option('EndPageBox') : 'off';
																	  foreach ( $toggle_options as $option_value ) {
																					printf(
																						'<option value="%1$s" %2$s>%1$s</option>',
																						esc_attr( $option_value ),
																						"{$option_value}" === $selected_value_EndPageBox ? 'selected="selected"' : ''
																					);
																		}

																		echo '</select>';

																		echo sprintf(
																					'<div class="et_pb_yes_no_button et_pb_%1$s_state" style="max-width: 195px;">
																						<span class="et_pb_value_text et_pb_on_value">%2$s</span>
																						<span class="et_pb_button_slider"></span>
																						<span class="et_pb_value_text et_pb_off_value">%3$s</span>
																					</div>',
																					esc_attr( $selected_value_EndPageBox ),
																					esc_html__( 'On' ),
																					esc_html__( 'Off' )
																		);

																		echo '</select>';
																		?><br /><br />
																	
																	This effect will let you add an end page box that will display when scrolled to the bottom or in any range on the page. <br /><br />
																
															<b>How to use: </b><br /><br />
																
																1.	Create a section and put up all the modules you want into that section<br /><br />
2.	At the end of the section add below code in a separate text module<br /><br />
3.	Modify the code the way you want: Remove unnecessary parts from the code &lt;div id="endpage-box" class="endpage-box"&gt; &lt;strong&gt;A &lt;/strong&gt; Paragraph 1: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore&lt;/div&gt; ...<br /><br />
																


																<b>Structure</b><br />
																
																 &lt;div id="endpage-box" class="endpage-box"&gt; &lt;strong&gt;A &lt;/strong&gt;
    Paragraph 1: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore&lt;/div&gt;
	 &lt;div id="endpage-box2" class="endpage-box"&gt; &lt;strong&gt;B &lt;/strong>Paragraph 3: nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit &lt;/div&gt;
	 &lt;div id="endpage-box3" class="endpage-box"&gt; &lt;strong&gt;C &lt;/strong>Paragraph 5: veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit &lt;/div&gt;
	 &lt;div id="endpage-box4" class="endpage-box"&gt; &lt;strong&gt;D &lt;/strong>Paragraph 7: incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation &lt;/div&gt;
	 
																</p><br /><br />
																<b>Note: You can also put this code with a text module at very end of the page. That way separate boxes like in example, A, B,.. Will appear throughout the page automatically.</b><br /><br />
																	<b>Source:</b> 
																	  <a href="https://github.com/peachananr/endpage-box"  target="_blank"> https://github.com/peachananr/endpage-box</a> 
															   </div>	
										      </div><!-- .epanel-box -->
											   
												</div>	   
												      
											
										 </div>

										</div><!-- #epanel-header -->
										<div id="epanel-bottom" class="scollbottom">
														<?php
															// Print nonce
															wp_nonce_field( $nonce, $nonce );
							
															// Print submit button
															printf(
																'<button class="save-button" name="save" id="epanel-save">%s</button>',
																esc_attr( 'Save Settings' )
															);
														?><br/><br/>
														<h3 style="color:#F3406F; font-weight: 600; font-size: 1.3em;"><u>How to use this plugin</u></h3><br/>
											In order to make most of these effects work in the Divi builder you have to give CSS class or ID. You can find these settings in any Divi Section/Row/Module under custom CSS tab. All of these CSS classes are working in custom HTML code, Text Module and Code Module<br/><br/>
Currently activated effect headings are highlighted in blue
<br/><br/>

<h3 style="color:#F3406F; font-weight: 600; font-size: 1.3em;"><u>Please Note:</u></h3><br/>

Try out different modules and column arrangements to make some of these effects work properly. You will understand how each effect behaves when you try out them in different setups.<br/><br/>

Some of these effects <b style="font-weight: 600; font-size: 1.1em;">(pagePiling, doSlide)</b> are not optimized for mobile screen sizes. For such effects please use <b>a single module inside a section</b>. This way the module adjusts its size properly in mobile view. You may want to <b style="font-weight: 600; font-size: 1.1em;"> activate 'Hide Divi Theme Header when scrolling' </b> to make these effects appear better
<br/><br/>
Sometimes you have to <b style="font-weight: 600; font-size: 1.1em;"> disable default module animations </b> to make the effect work properly
<br/><br/>
Activating many effects at once can cause conflicts

<br/><br/>

											</div><!-- #epanel-bottom -->
											
									</form>	
									</div><!-- #epanel-content -->
								</div><!-- #epanel-content-wrap -->
							</div><!-- #epanel -->
						</div><!-- #epanel-wrapper -->


				</div><!-- #panel-wrap -->
</div>