<?php
/*
 * Plugin Name: Ultimate Divi Builder Addons
 * Plugin URI:  https://divibuilderaddons.com/
 * Version: 1.0
 * Description:  <a href="https://divibuilderaddons.com/">'Ultimate Divi Builder Addons'</a> (UDBA) allows you to activate popular jQuery libraries that used by million dollar websites with switch of a toggle.
 * Author: Divi Builder Addons
 * Author URI: https://divibuilderaddons.com/ 
 * License: GPLv2 or later
 */

define('SE_PATH', plugin_dir_path(__FILE__ ));
define('SE_PATH_URL', plugin_dir_url(__FILE__));
add_action('plugins_loaded', 'scroll_init');

require_once(dirname(__FILE__) . "/class.wp-auto-plugin-update.php");
# Load the language files
function scroll_init(){
	load_plugin_textdomain( 'scroll', false, plugin_basename( dirname( __FILE__ )  . '/languages/' ));
}


/* Make Scroll in Admin Menu Item*/
add_action('admin_menu','scroll_setting',30);

/*
* Setup Admin menu item
*/
function scroll_setting(){
	add_menu_page('Ultimate Divi Builder Addons', 'Ultimate Divi Builder Addons', 'switch_themes', 'et_divi_ultimate_options', 'scroll_render_settings','dashicons-edit' );
}

function scroll_render_settings(){
	include SE_PATH."/include/scroll_options.php";
}

add_action( 'admin_enqueue_scripts', 'scroll_enqueue_scripts' );

/**
 * Enqueue dashboard scripts
 *
 * @return void
 */
function scroll_enqueue_scripts() {
	if ( isset( $_GET['page'] ) && ( 'et_divi_ultimate' === $_GET['page'] || ( 'et_divi_ultimate_options' === $_GET['page'] ) ) ) {
		$dependencies = array( 'jquery' );
		wp_enqueue_style( 'scroll-admin_style', plugin_dir_url( __FILE__ ) . 'css/admin-style.css', array(), '0.0.1' );
		wp_enqueue_style( 'spectrum-admin_style', plugin_dir_url( __FILE__ ) . 'css/spectrum.css', array(), '0.0.1' );
		wp_enqueue_style( 'customscroll-admin_style', plugin_dir_url( __FILE__ ) . 'css/custom-scroll.css', array(), '0.0.1' );
		wp_enqueue_script( 'customspectrumjs', plugin_dir_url( __FILE__ ) . 'js/spectrum.js', array(), '0.0.1',false);
		wp_enqueue_script( 'customscrolljs', plugin_dir_url( __FILE__ ) . 'js/scroll-custom.js', array(), '0.0.1',true);
		wp_enqueue_script( 'customjs', plugin_dir_url( __FILE__ ) . 'js/custom.js', array(), '0.0.1',true);
		wp_enqueue_style( 'css-ui', plugin_dir_url( __FILE__ ) . 'css/jquery-ui.css', array(), '0.0.1' );
		wp_enqueue_script( 'js-ui', plugin_dir_url( __FILE__ ) . 'js/jquery-ui.js');
		
		wp_enqueue_style( 'css-mCustomScrollbar', plugin_dir_url( __FILE__ ) . 'css/jquery.mCustomScrollbar.css', array(), '0.0.1' );
		//wp_enqueue_script( 'js-mCustomScrollbar', plugin_dir_url( __FILE__ ) . 'js/jquery.mCustomScrollbar.js');
		
		
		wp_localize_script( 'customscrolljs', 'et_divi_scroll_js_params',array(
					'help_label' => esc_html__( 'Help' ),
		) );
	}
}



add_action( 'wp_enqueue_scripts', 'scroll_enqueue_frontend_scripts' ) ;

function scroll_enqueue_frontend_scripts() {
		
		
		    $fadeintoview = get_option('fadeintoview');
			$wow = get_option('wow');
			$scrollmagic_responsive = get_option('scrollmagic_responsive');
			$scrollmagic_wipes= get_option('scrollmagic_wipes');
			$scrollreveal= get_option('scrollreveal');
			
			
			$doSlidehorizonltalTransition= get_option('doSlidehorizonltalTransition');
			
			$StickyStack= get_option('StickyStack');
			
			$LoadingEffect1= get_option('LoadingEffect1');
			$LoadingEffect2= get_option('LoadingEffect2');
			$LoadingEffect3= get_option('LoadingEffect3');
			$LoadingEffect4= get_option('LoadingEffect4');
			$ScrollFlow= get_option('ScrollFlow');
			$pagePiling= get_option('pagePiling');
			$pagePilingh= get_option('pagePilingh');
			$scrollingwindows= get_option('scrollingwindows');
			$scrollfx= get_option('scrollfx');
			$Revealator= get_option('Revealator');
			$scrollTrigger= get_option('scrollTrigger');
			
			$CustomScrollbar= get_option('CustomScrollbar');
			
			
			$HideScrollingDown= get_option('HideScrollingDown');
			$FlippingText= get_option('FlippingText');
			$SuperEasyTextRotator= get_option('SuperEasyTextRotator');
			$EndPageBox= get_option('EndPageBox');
		
			
		
		if( $fadeintoview == 'on' ){
			wp_enqueue_style( 'scrollcss-fadeintoview', plugin_dir_url( __FILE__ ) . 'asserts/jquery-fadeintoview/jquery-fadeintoview.css', array(), '0.0.1' );
			wp_enqueue_script( 'scrolljs-fadeintoview-velocity', plugin_dir_url( __FILE__ ) . 'asserts/jquery-fadeintoview/velocity.min.js', array(), '0.0.1',false);
			wp_enqueue_script( 'scrolljs-fadeintoview', plugin_dir_url( __FILE__ ) . 'asserts/jquery-fadeintoview/jquery-fadeintoview.js', array(), '0.0.1',false);
			wp_enqueue_script( 'scrolljs-fadeintoviewinit', plugin_dir_url( __FILE__ ) . 'asserts/jquery-fadeintoview/jquery-fadeintoview-init.js', array(), '0.0.1',false);
		}
		
		if( $wow == 'on' ){
	
			wp_enqueue_style( 'scrollcss-wow', plugin_dir_url( __FILE__ ) . 'asserts/WOW/animate.css', array(), '0.0.1' );
			wp_enqueue_script( 'scrolljs-wow', plugin_dir_url( __FILE__ ) . 'asserts/WOW/wow.min.js', array(), '0.0.1',true);
			wp_enqueue_script( 'scrolljs-wow-init', plugin_dir_url( __FILE__ ) . 'asserts/WOW/wow-init.js', array(), '0.0.1',true);

		}
		
		if( $scrollmagic_responsive == 'on' || $scrollmagic_wipes == 'on' ){
	
			wp_enqueue_style( 'scrollmagic-style', plugin_dir_url( __FILE__ ) . 'asserts/ScrollMagic/style.css', array(), '0.0.1' );
			
			
			
			wp_enqueue_script( 'scrollmagic-highlight', plugin_dir_url( __FILE__ ) . 'asserts/ScrollMagic/highlight.pack.js', array(), '0.0.1',true);
			wp_enqueue_script( 'scrollmagic-modernizr', plugin_dir_url( __FILE__ ) . 'asserts/ScrollMagic/modernizr.custom.min.js', array(), '0.0.1',true);

			wp_enqueue_script( 'scrollmagic-TweenMax', plugin_dir_url( __FILE__ ) . 'asserts/ScrollMagic/TweenMax.min.js', array(), '0.0.1',true);
			wp_enqueue_script( 'scrollmagic-ScrollMagic', plugin_dir_url( __FILE__ ) . 'asserts/ScrollMagic/ScrollMagic.js', array(), '0.0.1',true);
			wp_enqueue_script( 'scrollmagic-animation', plugin_dir_url( __FILE__ ) . 'asserts/ScrollMagic/animation.gsap.js', array(), '0.0.1',true);
			
			if( $scrollmagic_responsive == 'on' ){
				wp_enqueue_script( 'scrollmagic-init-Responsive-Duration', plugin_dir_url( __FILE__ ) . 'asserts/ScrollMagic/scrollmagic-init-responsive-duration.js', array(), '0.0.1',true);

			}
		
			if( $scrollmagic_wipes == 'on' ){
				wp_enqueue_script( 'scrollmagic-init-Section-Wipes', plugin_dir_url( __FILE__ ) . 'asserts/ScrollMagic/scrollmagic-init-section-wipes.js', array(), '0.0.1',true);
			}
			
		
		}
		
		if( $scrollreveal == 'on'){
			
			wp_enqueue_script( 'scrolljs-scrollreveal', plugin_dir_url( __FILE__ ) . 'asserts/scrollreveal/scrollreveal.js', array(), '0.0.1',true);
			wp_enqueue_script( 'scrolljs-scrollreveal-init', plugin_dir_url( __FILE__ ) . 'asserts/scrollreveal/scrollreveal-init.js', array(), '0.0.1',true);
			

		}
		
		
		if(    $doSlidehorizonltalTransition == 'on' ){
	
			wp_enqueue_style( 'doSlide-style', plugin_dir_url( __FILE__ ) . 'asserts/doSlide/do-slide.min.css', array(), '0.0.1' );
			wp_enqueue_script( 'doSlide-min', plugin_dir_url( __FILE__ ) . 'asserts/doSlide/do-slide.min.js', array(), '0.0.1',true);

		}
		
		
		
		if(  $doSlidehorizonltalTransition == 'on' ){
	
			wp_enqueue_script( 'doSlidehorizonltalTransition-init', plugin_dir_url( __FILE__ ) . 'asserts/doSlide/doSlidehorizonltalTransition.js', array(), '0.0.1',true);

		}
		
		
		
	
		if( $StickyStack == 'on'){
			
			wp_enqueue_style( 'StickyStack-style', plugin_dir_url( __FILE__ ) . 'asserts/StickyStack/sticky.css', array(), '0.0.1' );
			wp_enqueue_script( 'StickyStack-js', plugin_dir_url( __FILE__ ) . 'asserts/StickyStack/jquery.stickystack.js', array(), '0.0.1',true);
			wp_enqueue_script( 'StickyStack-init', plugin_dir_url( __FILE__ ) . 'asserts/StickyStack/stickystack.js', array(), '0.0.1',true);

		}
		
		if( $LoadingEffect1 == 'on'|| $LoadingEffect2 == 'on' || $LoadingEffect3 == 'on' || $LoadingEffect4 == 'on'){
			
			wp_enqueue_style( 'LoadingHeaderscrolling-style', plugin_dir_url( __FILE__ ) . 'asserts/LoadingHeader/loading-header-while-scrolling.css', array(), '0.0.1' );

			$primary_nav_bg = !empty(et_get_option( 'primary_nav_bg' )) ? et_get_option( 'primary_nav_bg' ) : '#ffffff';
			
			if( $LoadingEffect1 == 'on' ){
				wp_enqueue_script( 'LoadingEffect1-init', plugin_dir_url( __FILE__ ) . 'asserts/LoadingHeader/LoadingEffect1.js', array(), '0.0.1',true);
				 $LoadingEffect1colorft = !empty(get_option('LoadingEffect1color')) ? get_option('LoadingEffect1color') : '#EF4848';
				 
				 $LoadingEffect1c = "#loading {background-color: ".$LoadingEffect1colorft.";}";
				 wp_add_inline_style( 'LoadingHeaderscrolling-style', $LoadingEffect1c );
				 
			}
			
			if( $LoadingEffect2 == 'on' ){
				 $LoadingEffect2colorft = !empty(get_option('LoadingEffect2color')) ? get_option('LoadingEffect2color') : '#ef4848'; 
		         wp_enqueue_script( 'LoadingEffect2-init', plugin_dir_url( __FILE__ ) . 'asserts/LoadingHeader/LoadingEffect2.js', array(), '0.0.1',true);
			     wp_localize_script( 'LoadingEffect2-init', 'LoadingEffect2', array( 'LoadingEffect2colorft' => $LoadingEffect2colorft ,'primary_nav_bg'=> $primary_nav_bg) );
			   
			    
				 
			}
			
			if( $LoadingEffect3 == 'on' ){
			  $LoadingEffect3colorft = !empty(get_option('LoadingEffect3color')) ? get_option('LoadingEffect3color') : '#ef4848'; 

		       wp_enqueue_script( 'LoadingEffect3-init', plugin_dir_url( __FILE__ ) . 'asserts/LoadingHeader/LoadingEffect3.js', array(), '0.0.1',true);
			   wp_localize_script( 'LoadingEffect3-init', 'LoadingEffect3', array( 'LoadingEffect3colorft' => $LoadingEffect3colorft,'primary_nav_bg'=> $primary_nav_bg ) );
				
				 $LoadingEffect3c = "#loading {background-color: ".$LoadingEffect3colorft.";}";
				 wp_add_inline_style( 'LoadingHeaderscrolling-style', $LoadingEffect3c );
			}
		
			if( $LoadingEffect4 == 'on' ){
			  $LoadingEffect4colorft = !empty(get_option('LoadingEffect4color')) ? get_option('LoadingEffect4color') : '#ef4848'; 

		       wp_enqueue_script( 'LoadingEffect4-init', plugin_dir_url( __FILE__ ) . 'asserts/LoadingHeader/LoadingEffect4.js', array(), '0.0.1',true);
			   wp_localize_script( 'LoadingEffect4-init', 'LoadingEffect4', array( 'LoadingEffect4colorft' => $LoadingEffect4colorft,'primary_nav_bg'=> $primary_nav_bg ) );
				
			}

		}
		
	   
		
		if( $ScrollFlow == 'on' ){
			wp_enqueue_style( 'ScrollFlow-style', plugin_dir_url( __FILE__ ) . 'asserts/ScrollFlow/eskju.jquery.scrollflow.css', array(), '0.0.1' );
	
			wp_enqueue_script( 'ScrollFlow-js', plugin_dir_url( __FILE__ ) . 'asserts/ScrollFlow/eskju.jquery.scrollflow.js', array(), '0.0.1',true);

		}
		
		if( $pagePiling == 'on' || $pagePilingh == 'on'){
			
			wp_enqueue_style( 'pagePilingjquery-style', plugin_dir_url( __FILE__ ) . 'asserts/pagePiling/jquery.pagepiling.css', array(), '0.0.1' );
			wp_enqueue_script( 'pagePiling-js', plugin_dir_url( __FILE__ ) . 'asserts/pagePiling/jquery.pagepiling.js', array(), '0.0.1',true);
			wp_enqueue_style( 'pagePiling-style', plugin_dir_url( __FILE__ ) . 'asserts/pagePiling/pagepiling.css', array(), '0.0.1' );
			if($pagePiling == 'on'){
				wp_enqueue_script( 'pagePiling-init', plugin_dir_url( __FILE__ ) . 'asserts/pagePiling/pagePiling.js', array(), '0.0.1',true);
			}
			
			if($pagePilingh == 'on'){
				wp_enqueue_style( 'pagePilingh-style', plugin_dir_url( __FILE__ ) . 'asserts/pagePiling/pagepilingh.css', array(), '0.0.1' );
				wp_enqueue_script( 'pagePilingh-init', plugin_dir_url( __FILE__ ) . 'asserts/pagePiling/pagePilingh.js', array(), '0.0.1',true);
			}
			
	
		}
		
		if( $scrollingwindows == 'on' ){
			
			wp_enqueue_script( 'scrollingwindows-windows', plugin_dir_url( __FILE__ ) . 'asserts/scrollingwindows/jquery.windows.js', array(), '0.0.1',true);
            wp_enqueue_script( 'scrollingwindows-init', plugin_dir_url( __FILE__ ) . 'asserts/scrollingwindows/window-init.js', array(), '0.0.1',true);

	
		}
		
	
		
		if( $scrollfx == 'on'){
			
			//wp_enqueue_style( 'scrollfx-css', plugin_dir_url( __FILE__ ) . 'asserts/scrollfx/scrollfx.css', array(), '0.0.1' );
			wp_enqueue_script( 'scrollfx-js', plugin_dir_url( __FILE__ ) . 'asserts/scrollfx/jquery.scrollfx.js', array(), '0.0.1',true);
            wp_enqueue_script( 'scrollfx-init', plugin_dir_url( __FILE__ ) . 'asserts/scrollfx/scrollfx-init.js', array(), '0.0.1',true);

	
		}
		
		if( $Revealator == 'on'){
			
			wp_enqueue_style( 'Revealator-css', plugin_dir_url( __FILE__ ) . 'asserts/Revealator/fm.revealator.jquery.css', array(), '0.0.1' );
            wp_enqueue_script( 'Revealator-js', plugin_dir_url( __FILE__ ) . 'asserts/Revealator/fm.revealator.jquery.js', array(), '0.0.1',true);

	
		}
		
		if(  $scrollTrigger == 'on' ){
			
			wp_enqueue_style( 'scrollTrigger-css', plugin_dir_url( __FILE__ ) . 'asserts/scrollTrigger/scrollTrigger.css', array(), '0.0.1' );
            wp_enqueue_script( 'scrollTrigger-js', plugin_dir_url( __FILE__ ) . 'asserts/scrollTrigger/scrollTrigger.js', array(), '0.0.1',true);
            wp_enqueue_script( 'scrollTriggerinit-js', plugin_dir_url( __FILE__ ) . 'asserts/scrollTrigger/scrollTriggerinit.js', array(), '0.0.1',true);
	
		}
		
		
		
		if( $CustomScrollbar == 'on'  ){
			wp_enqueue_style( 'CustomScrollbar-css', plugin_dir_url( __FILE__ ) . 'asserts/CustomScrollbar/jquery.mCustomScrollbar.css', array(), '0.0.1' );
			wp_enqueue_style( 'CustomScrollbar-stylecss', plugin_dir_url( __FILE__ ) . 'asserts/CustomScrollbar/style.css', array(), '0.0.1' );

            wp_enqueue_script( 'CustomScrollbar-js', plugin_dir_url( __FILE__ ) . 'asserts/CustomScrollbar/jquery.mCustomScrollbar.concat.min.js', array(), '0.0.1',true);
          
		   	if( $CustomScrollbar == 'on' ){
			 	wp_enqueue_script( 'CustomScrollbarinit-js', plugin_dir_url( __FILE__ ) . 'asserts/CustomScrollbar/CustomScrollbarinit.js', array(), '0.0.1',true);
	
			}
		   
			
		}
		
		
		
		
		if( $HideScrollingDown == 'on' ){
			wp_enqueue_style( 'HideScrollingDown-css', plugin_dir_url( __FILE__ ) . 'asserts/HideScrollingDown/HideScrollingDown.css', array(), '0.0.1' );     
            wp_enqueue_script( 'HideScrollingDown-js', plugin_dir_url( __FILE__ ) . 'asserts/HideScrollingDown/HideScrollingDown.js', array(), '0.0.1',true);    
	
		}
		
		if( $FlippingText == 'on' ){

            wp_enqueue_script( 'FlippingText-js', plugin_dir_url( __FILE__ ) . 'asserts/FlippingText/jquery.flipping_text.js', array(), '0.0.1',true);    
            wp_enqueue_script( 'FlippingTextinit-js', plugin_dir_url( __FILE__ ) . 'asserts/FlippingText/flipping.js', array(), '0.0.1',true);    
     
		}
		
		if( $SuperEasyTextRotator == 'on' ){
			wp_enqueue_style( 'SuperEasyTextRotator-css', plugin_dir_url( __FILE__ ) . 'asserts/SuperEasyTextRotator/simpletextrotator.css', array(), '0.0.1' );     
            wp_enqueue_script( 'SuperEasyTextRotator-js', plugin_dir_url( __FILE__ ) . 'asserts/SuperEasyTextRotator/jquery.simple-text-rotator.js', array(), '0.0.1',true);
			wp_enqueue_script( 'textrotator-js', plugin_dir_url( __FILE__ ) . 'asserts/SuperEasyTextRotator/textrotator.js', array(), '0.0.1',true);    
   
  
		}
		
		if( $EndPageBox == 'on' ){
			wp_enqueue_style( 'EndPageBox-css', plugin_dir_url( __FILE__ ) . 'asserts/EndPageBox/endpage-box.css', array(), '0.0.1' );     
            wp_enqueue_script( 'EndPageBox-js', plugin_dir_url( __FILE__ ) . 'asserts/EndPageBox/jquery.endpage-box.js', array(), '0.0.1',true);
			wp_enqueue_script( 'endpage-js', plugin_dir_url( __FILE__ ) . 'asserts/EndPageBox/endpage.js', array(), '0.0.1',true);    
   
  
		}
		
		
		
	}
